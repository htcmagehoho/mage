#!/system/bin/sh

  ui_print "************************************"
  ui_print " sony korea xperia settings "
  ui_print "************************************"